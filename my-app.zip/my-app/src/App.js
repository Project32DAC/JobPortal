

import React from 'react';
import Login from './Component/Login';
import Signup from './Component/Signup';
import Home from './Component/Home';
import {BrowserRouter,Routes,Route} from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import About from './Component/About';
function App() {
  return (
    <BrowserRouter>
      <Routes>
         <Route path="/" element={<Home />} /> 
         
          <Route path="/login" element = {<Login/>} />
         <Route path="/Signup" element = {<Signup/>} />
         <Route path="/About" element = {<About/>} />
        {/* <Route exact path='/profile'>
               {userType() ==="recruiter" ?
               (
                <RecruiterProfile/>

               ):
               (
                <Profile/>
               )

               }

        </Route>
        <Route>
                <ErrorPage />
        </Route> */}


      </Routes>
    
    
    
    </BrowserRouter>
  );
}

export default App;
