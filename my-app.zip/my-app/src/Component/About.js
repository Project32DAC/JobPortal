import Base from "./Base";
const About = () =>
{
   return(
    <h1>
        <Base>
        This is my about component
        </Base>
    </h1>

   );
};
export default About;