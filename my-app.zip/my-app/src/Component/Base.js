import CustomNavbar from "./CustomNavbar";

const Base= ({ title = "welcome to job portal",children}) =>
{
    return(
            <div className="container-fluid">
                {/* <h1>This is header</h1> */}
                 <CustomNavbar></CustomNavbar>
                {children}
 
                <h1>This is footer</h1>
            </div>
    );
};
export default Base;