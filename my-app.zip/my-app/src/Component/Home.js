import React from "react";
import Base from "./Base"

const Home = () =>
{
    return(
       <Base>
                     
        <h1>this is home page</h1>
       
       </Base>    
        

    );
};
export default Home;