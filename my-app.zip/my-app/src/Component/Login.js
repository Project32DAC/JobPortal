import React from "react";
import { Button } from "reactstrap";
import Base from "./Base";
const Login = () =>
{
    return(
        <Base>
         
            <Button>This is login</Button>


        </Base>

    );
};
export default Login;