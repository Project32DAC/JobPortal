const Signup = () =>
{
    return(
        <h1>This is sign up page</h1>
    );
};
export default Signup;
